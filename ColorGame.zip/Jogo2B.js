var colorsArr = [];
var divsColor = document.querySelectorAll(".cores");
var dif = 9;
var colorSelect = indic();//Math.floor(Math.random() * dif); //elects randomly the index for the Hero color
// Function that creates random colors
function sorteia(){
    var cor = "rgb(" + Math.floor(Math.random() * 256) + ", " + Math.floor(Math.random() * 256) + ", " + Math.floor(Math.random() * 256) + ")";
    return colorsArr.push(cor);
}
// Functions that assigns colors to the colorsArr[]
function atribui (){
    for (i=0; i<dif; i++){
        sorteia();
        divsColor[i].style.background = colorsArr[i];
    }
}

// jQuery that calls the init() function when the divs are drawn to the page
$(".cores").ready(init());

function init(){
    atribui();
    // Here the selected color is set to colorSelect and displayed in the title h1
    colorSelect = colorsArr[colorSelect].toString();
    document.querySelector("#corSelecionada").textContent = colorSelect;
}

// Listens the clicks in the div .cores to notice wich was clicked
$(".cores").click(function(){
    var $div = $(this).css("background-color");
    if ($div === colorSelect){
        $(".cores").css("background-color", $div);
        $("#mensagem").text("CERTO!!!");
        $("#sorteia").text("Jogar Novamente?");
        $(".cores").text("");
    } else {
        $(this).css({
            background: "#b1c9ef",
            color: $div,
        });
        $(this).text($div);
        $("#mensagem").text("Não, tente de novo.");
    }
});
// Function that listens the reset and the other buttons
$("button").click(function(){
    var $Button = $(this).attr("id");
    switch ($Button){
        case "sorteia":
            reset();
            break;

        case "facil":
            dif = 3;
            hideDiv();
            reset();   
            $("button").removeClass("dif");
            $(this).addClass("dif");
            break;

        case "medio":
        dif = 6;
        restore();
        hideDiv();
        reset();
        $("button").removeClass("dif");
        $(this).addClass("dif");
        break;

        case "dificil":
        dif = 9;
        restore();
        reset();
        $("button").removeClass("dif");
        $(this).addClass("dif");
        break;
    }
});
// Clean Array function
function cleanArr(){
    for (i = 0; i < 9; i++) {
        colorsArr.shift();
    };
}
//Function Reset
function reset(){
        cleanArr();
        $(".cores").each(function(){
            atribui();
        });
        colorSelect = indic();
        init();
        $("#sorteia").text("Sorteia");
        $("#mensagem").text("Pronto para jogar?");
    }
// Function hide the unwanted divs
function hideDiv(){
    for (i=8; i>=dif; i--){
        document.getElementsByClassName("cores")[i].style.display = "none";
    }
}
// Function to randonly select an index
function indic(){
    var temp = Math.floor(Math.random() * dif);
    return temp;
}
// Function that shows back the hidden divs
function restore(){
    for (i=0; i<dif; i++){
        document.getElementsByClassName("cores")[i].style.display = "block";
    }
}